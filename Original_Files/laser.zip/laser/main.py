#!/usr/bin/python3

# 导入相关库

from lc12s import Lc12s
from camera import Detector
import cv2
from enum import Enum
from camera import WebcamStream


# 枚举处理端状态
class Status(Enum):
    IDLE = 0  # 空闲态
    ENROLL_WEB = 1  # 注册网关
    GUN_ENROLL = 2  # 枪抢占
    QUIT = 4  # 退出
    CONFIRM_QUIT = 5  # 确认退出态\


# 枚举事件
class Event(Enum):
    NULL = 0  # 无事件
    ENROLL = 1  # 注册事件
    GUN_ENROLL = 2
    QUIT = 3  # 关闭摄像头
    SEND_CURVE = 4  # 发送轨迹信息
    SEND_POINT = 5  # 发送击中坐标信息


class Core(object):
    def __init__(self, wireless, detect, status, event):
        self.wireless = wireless
        self.detect = detect
        self.framerate = 40
        self.size = (480, 480)

        self.status = status
        self.event = event
        self.count = 0
        self.dis_10 = 100
        self.dis_9 = 160
        self.dis_8 = 200
        self.dis_7 = 224
        self.dis_6 = 240
        self.webcam_stream = WebcamStream(stream_id=0)  # stream_id = 0 is for primary camera

    def get_action(self):
        self.wireless.recv()
        self.wireless.get_message()

    def recv_fsm(self):
        self.get_action()
        while 1:
            # print(self.status)
            if self.status == Status.IDLE:
                if self.wireless.target_enroll:
                    self.wireless.target_enroll = False
                    self.status = Status.ENROLL_WEB
                    self.event = Event.NULL
                    self.count = 0
                    print("confirm target enroll")
                else:
                    self.status = Status.IDLE
                    self.event = Event.NULL
                    self.count = self.count + 1
                    if self.count % 5 == 0:
                        print("target enroll")
                        self.status = Status.IDLE
                        self.event = Event.NULL
                        self.count = 0
                        self.wireless.enroll()
                break
            if self.status == Status.ENROLL_WEB:
                if self.wireless.receive_enroll_flag:  # enroll ack
                    self.status = Status.GUN_ENROLL  # gun enroll
                    self.event = Event.GUN_ENROLL
                    self.count = 0
                else:
                    # print("wait for gun")
                    self.status = Status.ENROLL_WEB
                    self.event = Event.NULL
                    self.count = self.count + 1
                    if self.count > 600:
                        print("timeout ")
                    self.count = 0
                break
            if self.status == Status.GUN_ENROLL:
                # gun enroll
                # print("gun enroll")
                if self.wireless.receive_data_flag:
                    self.wireless.core_web_flag = True
                    self.wireless.receive_data_flag = False
                if self.wireless.receive_quit_flag:
                    print("gun quit request")
                    self.wireless.receive_quit_flag = False
                    self.status = Status.ENROLL_WEB
                    self.event = Event.QUIT
                    self.count = 0
                    break
                if self.wireless.core_web_flag and self.detect.open_flag:
                    self.status = Status.GUN_ENROLL
                    self.event = Event.SEND_POINT
                    self.wireless.core_web_flag = False
                else:
                    if self.detect.open_flag:
                        self.status = Status.GUN_ENROLL
                        self.event = Event.SEND_CURVE
                        self.count = 0
                # enroll
                break
            else:
                break

    def event_handle(self):
        self.recv_fsm()
        # print(self.event)
        while 1:
            if self.event == Event.GUN_ENROLL:
                self.detect.open_flag = True
                self.event = Event.NULL
                print("open camera")
                break
            if self.event == Event.QUIT:
                self.wireless.open_flag = False
                self.wireless.receive_quit_flag = False
                self.wireless.receive_enroll_flag = False
                cv2.destroyAllWindows()
                self.webcam_stream.stop()  # stop the webcam stream
                # self.webcam_stream.vcap.release()
                self.event = Event.NULL
                print("close camera")
                break
            if self.event == Event.SEND_CURVE:
                if self.webcam_stream.stopped is True:
                    break
                else:
                    frame = self.webcam_stream.read()
                self.detect.mask(0x00, frame)
                mes = self.detect.update(0x00)
                if self.detect.update_flag:
                    self.detect.update_flag = 0
                    self.wireless.hit(0x00, mes[0], mes[1], mes[2], mes[3], mes[4], mes[5], mes[6], mes[7])
                    self.event = Event.NULL
                break
            elif self.event == Event.SEND_POINT:
                if self.webcam_stream.stopped is True:
                    break
                else:
                    frame = self.webcam_stream.read()
                self.detect.mask(0x01, frame)
                mes = self.detect.update(0x01)
                if self.detect.update_flag:
                    self.detect.update_flag = 0
                    self.wireless.hit(0x01, mes[0], mes[1], mes[2], mes[3], mes[4], mes[5], mes[6], mes[7])
                    self.event = Event.NULL
                break
            else:
                self.event = Event.NULL
                break


lc12s = Lc12s(9600, 25, 0x01, 0xc8, 0x00, 0x0C, 0x1E, 0x14, 0X12)
camera = Detector(False)
axis = []


def main():
    core = Core(lc12s, camera, Status.IDLE, Event.NULL)
    core.webcam_stream.start()
    # processing frames in input stream
    while True:
        core.event_handle()


# 主程序部分
if __name__ == '__main__':
    main()
